import { Globe, ExternalLink } from "lucide-react";

export function WebPreview({ doc, onOpenTab }) {
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b border-border px-4 py-2 text-sm font-semibold">
        <span className="flex items-center gap-2">
          <Globe className="h-4 w-4 text-accent" />
          Live Preview
        </span>
        {onOpenTab && (
          <button
            onClick={onOpenTab}
            className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs text-muted-foreground transition hover:bg-muted hover:text-foreground"
            title="Open preview in a new tab"
          >
            <ExternalLink className="h-3.5 w-3.5" /> New tab
          </button>
        )}
      </div>
      <div className="flex-1 bg-white">
        <iframe
          title="preview"
          srcDoc={doc}
          sandbox="allow-scripts allow-modals allow-forms allow-popups"
          className="h-full w-full border-0"
        />
      </div>
    </div>
  );
}