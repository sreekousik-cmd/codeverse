import { Terminal, Trash2, Loader2, CheckCircle2, AlertCircle, Circle } from "lucide-react";
import { cn } from "@/lib/utils";

function StatusDot({ status }) {
  if (status === "running")
    return <Loader2 className="h-3.5 w-3.5 animate-spin text-primary" />;
  if (status === "ok") return <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />;
  if (status === "error") return <AlertCircle className="h-3.5 w-3.5 text-destructive" />;
  return <Circle className="h-3.5 w-3.5 text-muted-foreground" />;
}

export function ConsolePanel({ lines, status, running, onClear, meta }) {
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b border-border px-4 py-2">
        <div className="flex items-center gap-2 text-sm font-semibold">
          <Terminal className="h-4 w-4 text-primary" />
          Console
          <StatusDot status={status} />
        </div>
        <div className="flex items-center gap-3">
          {meta && <span className="text-xs text-muted-foreground">{meta}</span>}
          <button
            onClick={onClear}
            className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs text-muted-foreground transition hover:bg-muted hover:text-foreground"
            title="Clear console"
          >
            <Trash2 className="h-3.5 w-3.5" /> Clear
          </button>
        </div>
      </div>
      <div className="flex-1 overflow-auto bg-[hsl(var(--background))] font-mono text-sm">
        {lines.length === 0 && !running ? (
          <div className="flex h-full flex-col items-center justify-center gap-2 px-6 text-center text-muted-foreground">
            <Terminal className="h-8 w-8 opacity-30" />
            <p className="text-sm">Output will appear here after you run your code.</p>
          </div>
        ) : (
          <pre className="m-0 whitespace-pre-wrap break-words p-3 leading-relaxed">
            {lines.map((l, i) => (
              <div
                key={i}
                className={cn(
                  "py-0.5",
                  l.level === "error" && "text-destructive",
                  l.level === "warn" && "text-amber-400",
                  l.level === "info" && "text-sky-400",
                  l.level === "stdout" && "text-foreground",
                  l.level === "stderr" && "text-destructive",
                  l.level === "status" && "text-muted-foreground italic",
                  (l.level === "log" || l.level === "debug") && "text-foreground",
                )}
              >
                {l.text}
              </div>
            ))}
            {running && <div className="py-0.5 text-muted-foreground">▌</div>}
          </pre>
        )}
      </div>
    </div>
  );
}