import { Keyboard } from "lucide-react";

export function StdinPanel({ value, onChange, disabled }) {
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 border-b border-border px-4 py-2 text-sm font-semibold">
        <Keyboard className="h-4 w-4 text-primary" />
        Standard Input
      </div>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        spellCheck={false}
        placeholder={"Enter standard input here, one value per line.\n\nExample:\nAda\n30"}
        className="flex-1 resize-none bg-[hsl(var(--background))] p-3 font-mono text-sm text-foreground outline-none placeholder:text-muted-foreground/60 disabled:opacity-50"
      />
    </div>
  );
}