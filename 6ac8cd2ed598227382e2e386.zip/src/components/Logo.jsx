import { Code2 } from "lucide-react";
import { cn } from "@/lib/utils";

export function Logo({ className, showText = true, size = "md" }) {
  const iconSize = size === "sm" ? "h-5 w-5" : size === "lg" ? "h-8 w-8" : "h-6 w-6";
  return (
    <span className={cn("inline-flex items-center gap-2 font-extrabold tracking-tight", className)}>
      <span className="grid place-items-center rounded-xl bg-gradient-to-br from-primary to-accent text-primary-foreground shadow-lg shadow-primary/30">
        <Code2 className={cn(iconSize, "m-1")} />
      </span>
      {showText && (
        <span className="text-lg leading-none">
          Code<span className="cv-gradient-text">Verse</span>
        </span>
      )}
    </span>
  );
}