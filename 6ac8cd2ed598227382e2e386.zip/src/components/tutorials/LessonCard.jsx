import { Link } from "@tanstack/react-router";
import { Play, Lightbulb } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export function LessonCard({ lesson, index, color }) {
  const code = lesson.lang === "web" ? lesson.html : lesson.code;
  return (
    <Card className="border-border bg-card/50 transition hover:border-primary/40">
      <CardContent className="flex flex-col gap-3 p-5">
        <div className="flex items-start gap-3">
          <span
            className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-sm font-bold"
            style={{ background: `${color}22`, color }}
          >
            {index + 1}
          </span>
          <div>
            <h3 className="font-semibold leading-tight">{lesson.title}</h3>
            <p className="mt-1.5 text-sm text-muted-foreground">{lesson.body}</p>
          </div>
        </div>

        <pre className="overflow-x-auto rounded-lg border border-border bg-background p-4 font-mono text-xs leading-relaxed text-foreground">
          {code}
        </pre>

        {lesson.tip && (
          <p className="flex gap-2 rounded-lg bg-muted/60 p-3 text-xs text-muted-foreground">
            <Lightbulb className="mt-0.5 h-3.5 w-3.5 shrink-0" style={{ color }} />
            <span>{lesson.tip}</span>
          </p>
        )}

        <div>
          <Button asChild size="sm" variant="outline">
            <Link to="/playground" search={{ tutorial: lesson.id }}>
              <Play className="h-3.5 w-3.5" /> Open in Playground
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}