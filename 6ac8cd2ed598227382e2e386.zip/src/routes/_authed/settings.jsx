import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useTheme } from "next-themes";
import { useAuth } from "@/lib/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ThemeToggle } from "@/components/ThemeToggle";
import { MODE_LIST } from "@/lib/languages";
import { MemoryPanel } from "@/components/settings/MemoryPanel";
import { Minus, Plus, Sun, Moon, LogOut, User as UserIcon } from "lucide-react";

export const Route = createFileRoute("/_authed/settings")({
  ssr: false,
  head: () => ({ meta: [{ title: "Settings — CodeVerse" }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const { user, logout } = useAuth();
  const { resolvedTheme, setTheme, mounted } = useTheme();
  const [defaultLang, setDefaultLang] = useState("python");
  const [fontSize, setFontSize] = useState(14);

  useEffect(() => {
    setDefaultLang(localStorage.getItem("cv-default-lang") || "python");
    setFontSize(Number(localStorage.getItem("cv-fontsize") || 14));
  }, []);

  function saveLang(l) {
    setDefaultLang(l);
    localStorage.setItem("cv-default-lang", l);
  }
  function saveFont(n) {
    const v = Math.min(28, Math.max(10, n));
    setFontSize(v);
    localStorage.setItem("cv-fontsize", String(v));
  }

  const isDark = !mounted || resolvedTheme !== "light";

  return (
    <div className="mx-auto max-w-2xl px-4 py-12">
      <header className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="mt-2 text-muted-foreground">Personalize your CodeVerse experience.</p>
      </header>

      <div className="space-y-5">
        <Card className="border-border bg-card/50">
          <CardHeader>
            <CardTitle className="text-base">Appearance</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Theme</Label>
                <p className="text-sm text-muted-foreground">Dark is recommended for coding.</p>
              </div>
              <Button variant="outline" onClick={() => setTheme(isDark ? "light" : "dark")} className="gap-2">
                {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
                {isDark ? "Light" : "Dark"}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border bg-card/50">
          <CardHeader>
            <CardTitle className="text-base">Editor defaults</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Default language</Label>
                <p className="text-sm text-muted-foreground">Loaded when you start a new project.</p>
              </div>
              <Select value={defaultLang} onValueChange={saveLang}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {MODE_LIST.map((m) => (
                    <SelectItem key={m.id} value={m.id}>
                      {m.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label>Editor font size</Label>
                <p className="text-sm text-muted-foreground">Applied to the code editor.</p>
              </div>
              <div className="flex items-center gap-1 rounded-md border border-border px-1">
                <Button size="icon" variant="ghost" onClick={() => saveFont(fontSize - 1)} className="h-8 w-8">
                  <Minus className="h-3.5 w-3.5" />
                </Button>
                <span className="w-8 text-center text-sm tabular-nums">{fontSize}</span>
                <Button size="icon" variant="ghost" onClick={() => saveFont(fontSize + 1)} className="h-8 w-8">
                  <Plus className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <MemoryPanel />

        <Card className="border-border bg-card/50">
          <CardHeader>
            <CardTitle className="text-base">Account</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-primary to-accent text-sm font-bold text-primary-foreground">
                {user?.email ? user.email.slice(0, 2).toUpperCase() : "CV"}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 truncate font-medium">
                  <UserIcon className="h-3.5 w-3.5 text-muted-foreground" />
                  {user?.full_name || user?.email}
                </div>
                <div className="truncate text-sm text-muted-foreground">{user?.email}</div>
              </div>
            </div>
            <Button variant="outline" onClick={() => logout()} className="gap-2 text-destructive hover:text-destructive">
              <LogOut className="h-4 w-4" /> Sign out
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}