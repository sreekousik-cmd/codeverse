import { createFileRoute, Link } from "@tanstack/react-router";
import { EXAMPLES } from "@/lib/examples";
import { getMode } from "@/lib/languages";
import { ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/_site/examples")({
  head: () => ({ meta: [{ title: "Examples — CodeVerse" }] }),
  component: ExamplesPage,
});

function ExamplesPage() {
  const categories = [...new Set(EXAMPLES.map((e) => e.category))];
  return (
    <div className="mx-auto max-w-7xl px-4 py-12">
      <header className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Examples</h1>
        <p className="mt-2 text-muted-foreground">
          Load a ready-made program straight into the playground and run it.
        </p>
      </header>

      {categories.map((cat) => (
        <section key={cat} className="mb-10">
          <h2 className="mb-4 text-sm font-semibold uppercase tracking-wider text-muted-foreground">{cat}</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {EXAMPLES.filter((e) => e.category === cat).map((ex) => {
              const m = getMode(ex.language);
              const Icon = m.icon;
              return (
                <Link
                  key={ex.id}
                  to="/playground"
                  search={{ example: ex.id, lang: ex.language }}
                  className="group rounded-xl border border-border bg-card/50 p-5 transition hover:border-primary/50 hover:bg-card"
                >
                  <div className="flex items-center justify-between">
                    <div className="grid h-10 w-10 place-items-center rounded-lg" style={{ background: `${m.color}22`, color: m.color }}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <ArrowRight className="h-4 w-4 text-muted-foreground transition group-hover:translate-x-1 group-hover:text-primary" />
                  </div>
                  <h3 className="mt-4 font-semibold">{ex.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{ex.description}</p>
                  <span className="mt-3 inline-block rounded-md bg-muted px-2 py-0.5 text-xs text-muted-foreground">{m.label}</span>
                </Link>
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );
}