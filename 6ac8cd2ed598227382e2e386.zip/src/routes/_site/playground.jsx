const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";

import { runPythonPyodide, stopPython } from "@/lib/pyodideRunner";
import { PLAYGROUND_MODES, getMode } from "@/lib/languages";
import { getExample } from "@/lib/examples";
import { getTutorialLesson } from "@/lib/tutorials";
import { buildWebDoc, buildJsRunnerDoc } from "@/lib/sandbox";
import { useAuth } from "@/lib/AuthContext";
import { CodeEditor } from "@/components/CodeEditor";
import { Toolbar } from "@/components/playground/Toolbar";
import { EditorToolbar } from "@/components/playground/EditorToolbar";
import { ConsolePanel } from "@/components/playground/ConsolePanel";
import { StdinPanel } from "@/components/playground/StdinPanel";
import { WebPreview } from "@/components/playground/WebPreview";
import { useIsDesktop } from "@/hooks/useMediaQuery";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "@/components/ui/resizable";
import { Info } from "lucide-react";

export const Route = createFileRoute("/_site/playground")({
  ssr: false,
  validateSearch: (search) => ({
    example: typeof search.example === "string" ? search.example : undefined,
    lang: typeof search.lang === "string" ? search.lang : undefined,
    tutorial: typeof search.tutorial === "string" ? search.tutorial : undefined,
    project: typeof search.project === "string" ? search.project : undefined,
  }),
  head: () => ({ meta: [{ title: "Playground — CodeVerse" }] }),
  component: PlaygroundPage,
});

function PlaygroundPage() {
  const search = Route.useSearch();
  const { isAuthenticated, navigateToLogin } = useAuth();
  const isDesktop = useIsDesktop();

  const [language, setLanguage] = useState("python");
  const [source, setSource] = useState("");
  const [css, setCss] = useState("");
  const [js, setJs] = useState("");
  const [stdin, setStdin] = useState("");
  const [activeTab, setActiveTab] = useState("code");
  const [rightTab, setRightTab] = useState("console");
  const [projectName, setProjectName] = useState("");
  const [currentProject, setCurrentProject] = useState(null);
  const [dirty, setDirty] = useState(false);

  const [lines, setLines] = useState([]);
  const [status, setStatus] = useState("idle");
  const [running, setRunning] = useState(false);
  const [meta, setMeta] = useState("");
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState(false);
  const [fontSize, setFontSize] = useState(14);
  const [webDoc, setWebDoc] = useState("");

  const runIdRef = useRef(0);
  const cancelledRef = useRef(false);
  const jsRunnerRef = useRef(null);
  const loadedRef = useRef(false);

  // Font size persistence
  useEffect(() => {
    const s = localStorage.getItem("cv-fontsize");
    if (s) setFontSize(Number(s) || 14);
  }, []);
  useEffect(() => {
    localStorage.setItem("cv-fontsize", String(fontSize));
  }, [fontSize]);

  // Load from URL: project > example > lang > default
  useEffect(() => {
    if (loadedRef.current) return;
    loadedRef.current = true;
    (async () => {
      if (search.project) {
        try {
          const p = await db.entities.Project.get(search.project);
          setLanguage(p.language);
          setSource(p.source || "");
          setCss(p.css_code || "");
          setJs(p.js_code || "");
          setProjectName(p.name);
          setCurrentProject({ id: p.id, name: p.name });
          setRightTab(p.language === "web" ? "preview" : "console");
          setActiveTab(p.language === "web" ? "html" : "code");
          setDirty(false);
          return;
        } catch {
          toast.error("Could not open that project. It may have been deleted or is not yours.");
        }
      }
      if (search.example) {
        const ex = getExample(search.example);
        if (ex) {
          setLanguage(ex.language);
          if (ex.language === "web") {
            setSource(ex.html || "");
            setCss(ex.css || "");
            setJs(ex.js || "");
            setActiveTab("html");
            setRightTab("preview");
          } else {
            setSource(ex.code || "");
            setActiveTab("code");
            setRightTab("console");
          }
          setStdin(ex.stdin || "");
          setProjectName(ex.title);
          setCurrentProject(null);
          setDirty(false);
          return;
        }
      }
      if (search.tutorial) {
        const lesson = getTutorialLesson(search.tutorial);
        if (lesson) {
          setLanguage(lesson.lang);
          if (lesson.lang === "web") {
            setSource(lesson.html || "");
            setCss(lesson.css || "");
            setJs(lesson.js || "");
            setActiveTab("html");
            setRightTab("preview");
          } else {
            setSource(lesson.code || "");
            setActiveTab("code");
            setRightTab("console");
          }
          setStdin(lesson.stdin || "");
          setProjectName(`Tutorial — ${lesson.title}`);
          setCurrentProject(null);
          setDirty(false);
          return;
        }
      }
      const startLang =
        search.lang && PLAYGROUND_MODES[search.lang]
          ? search.lang
          : localStorage.getItem("cv-default-lang") && PLAYGROUND_MODES[localStorage.getItem("cv-default-lang")]
          ? localStorage.getItem("cv-default-lang")
          : "python";
      applyStarter(startLang);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function applyStarter(mode) {
    const m = getMode(mode);
    setLanguage(mode);
    if (mode === "web") {
      setSource(m.starter.html);
      setCss(m.starter.css);
      setJs(m.starter.js);
      setActiveTab("html");
      setRightTab("preview");
    } else {
      setSource(m.starter);
      setActiveTab("code");
      setRightTab("console");
    }
    setStdin("");
    setProjectName(`Untitled ${m.label} project`);
    setCurrentProject(null);
    setDirty(false);
  }

  // Live web preview (debounced)
  useEffect(() => {
    if (language !== "web") return;
    const t = setTimeout(() => {
      const id = ++runIdRef.current;
      setWebDoc(buildWebDoc(source, css, js, id));
      setLines([]);
      setStatus("idle");
      setMeta("");
    }, 400);
    return () => clearTimeout(t);
  }, [source, css, js, language]);

  // Console message listener (shared by JS runner + web preview)
  useEffect(() => {
    function onMsg(e) {
      const d = e.data;
      if (!d || !d.__cv) return;
      if (d.run !== undefined && d.run !== runIdRef.current) return;
      if (d.type === "log") setLines((prev) => [...prev, { level: d.level, text: d.text }]);
      else if (d.type === "error") {
        setLines((prev) => [...prev, { level: "error", text: d.text }]);
        setStatus("error");
      } else if (d.type === "done") {
        setRunning(false);
        setStatus(d.exitCode === 0 ? "ok" : "error");
        setMeta(`exit ${d.exitCode}`);
      }
    }
    window.addEventListener("message", onMsg);
    return () => window.removeEventListener("message", onMsg);
  }, []);

  const mode = getMode(language);
  const editorValue =
    language === "web"
      ? activeTab === "html"
        ? source
        : activeTab === "css"
        ? css
        : js
      : source;
  const editorLang =
    language === "web"
      ? activeTab === "html"
        ? "html"
        : activeTab === "css"
        ? "css"
        : "javascript"
      : mode.monaco;

  function setEditorValue(val) {
    setDirty(true);
    if (language === "web") {
      if (activeTab === "html") setSource(val);
      else if (activeTab === "css") setCss(val);
      else setJs(val);
    } else setSource(val);
  }

  function handleLanguageChange(newLang) {
    if (newLang === language) return;
    if (dirty && !window.confirm("Switching languages will discard your current code. Continue?")) return;
    applyStarter(newLang);
    setLines([]);
    setStatus("idle");
    setMeta("");
  }

  async function handleRun() {
    if (language === "python") return runPythonCode();
    if (language === "javascript") return runJsCode();
    if (language === "web") return runWebRefresh();
  }

  function runWebRefresh() {
    const id = ++runIdRef.current;
    setWebDoc(buildWebDoc(source, css, js, id));
    setLines([]);
    setStatus("ok");
    setMeta("preview refreshed");
    toast("Preview refreshed");
  }

  async function runPythonCode() {
    if (!source.trim()) {
      toast.error("Write some Python code first.");
      return;
    }
    setRunning(true);
    setStatus("running");
    setLines([]);
    setMeta("running…");
    const myRun = ++runIdRef.current;
    cancelledRef.current = false;
    try {
      const res = await runPythonPyodide({
        code: source,
        stdin,
        onLoading: () => {
          if (myRun === runIdRef.current) setMeta("Loading Python runtime… first run downloads the engine");
        },
      });
      if (cancelledRef.current || myRun !== runIdRef.current) return;
      if (res.stopped) return;
      const out = [];
      if (res.stdout) out.push({ level: "stdout", text: res.stdout.replace(/\n$/, "") });
      if (res.stderr) out.push({ level: "stderr", text: res.stderr.replace(/\n$/, "") });
      if (out.length === 0) out.push({ level: "status", text: "Program finished with no output." });
      setLines(out);
      setStatus(res.exitCode === 0 ? "ok" : "error");
      setMeta(`exit ${res.exitCode} · CPython ${res.exitCode === 0 ? "(Pyodide)" : ""}`.trim());
    } catch (e) {
      if (cancelledRef.current) return;
      setLines([{ level: "error", text: "Python execution failed: " + (e?.message || e) }]);
      setStatus("error");
    } finally {
      if (myRun === runIdRef.current) setRunning(false);
    }
  }

  function runJsCode() {
    if (!source.trim()) {
      toast.error("Write some JavaScript first.");
      return;
    }
    setRunning(true);
    setStatus("running");
    setLines([]);
    setMeta("running…");
    const id = ++runIdRef.current;
    const iframe = jsRunnerRef.current;
    if (!iframe) return;
    iframe.srcdoc = buildJsRunnerDoc(source, stdin, id);
  }

  function handleStop() {
    cancelledRef.current = true;
    runIdRef.current++;
    if (language === "javascript" && jsRunnerRef.current) jsRunnerRef.current.srcdoc = "";
    if (language === "python") stopPython();
    setRunning(false);
    setStatus("idle");
    setMeta("stopped");
    setLines((prev) => [...prev, { level: "status", text: "Execution stopped." }]);
  }

  async function handleSave() {
    if (!isAuthenticated) {
      toast.info("Sign in to save your work.");
      navigateToLogin();
      return;
    }
    if (!projectName.trim()) {
      toast.error("Give your project a name first.");
      return;
    }
    setSaving(true);
    try {
      const payload = {
        name: projectName.trim(),
        language,
        source,
        css_code: css,
        js_code: js,
      };
      if (currentProject?.id) {
        await db.entities.Project.update(currentProject.id, payload);
        toast.success("Project saved.");
      } else {
        const created = await db.entities.Project.create(payload);
        setCurrentProject({ id: created.id, name: created.name });
        toast.success("Project created.");
      }
      setDirty(false);
    } catch (e) {
      toast.error("Could not save: " + (e?.message || e));
    } finally {
      setSaving(false);
    }
  }

  function handleCopy() {
    navigator.clipboard.writeText(editorValue).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
      toast.success("Copied to clipboard.");
    });
  }

  function handleDownload() {
    let content = editorValue;
    let ext = mode.ext;
    if (language === "web") {
      ext = activeTab === "html" ? "html" : activeTab === "css" ? "css" : "js";
    }
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(projectName || "code").replace(/\s+/g, "_")}.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function handleClear() {
    setEditorValue("");
  }

  function openPreviewInTab() {
    const blob = new Blob([webDoc], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank");
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }

  function handleReset() {
    if (!window.confirm("Reset this tab to the starter template?")) return;
    const m = getMode(language);
    if (language === "web") {
      if (activeTab === "html") setSource(m.starter.html);
      else if (activeTab === "css") setCss(m.starter.css);
      else setJs(m.starter.js);
    } else {
      setSource(m.starter);
    }
    setDirty(true);
  }

  const editorTabs =
    language === "web"
      ? [
          { id: "html", label: "HTML" },
          { id: "css", label: "CSS" },
          { id: "js", label: "JS" },
        ]
      : [{ id: "code", label: mode.label }];

  return (
    <div className="flex h-[calc(100vh-4rem)] flex-col overflow-hidden">
      {!isAuthenticated && (
        <div className="flex items-center gap-2 border-b border-amber-500/30 bg-amber-500/10 px-4 py-1.5 text-xs text-amber-500">
          <Info className="h-3.5 w-3.5" />
          You're coding as a guest. Sign in to save your work — unsaved code may be lost.
        </div>
      )}

      <Toolbar
        projectName={projectName}
        onProjectNameChange={(v) => {
          setProjectName(v);
          setDirty(true);
        }}
        language={language}
        onLanguageChange={handleLanguageChange}
        onRun={handleRun}
        onStop={handleStop}
        onSave={handleSave}
        running={running}
        saving={saving}
        dirty={dirty}
        saveDisabled={false}
      />

      <div className="min-h-0 flex-1 p-3">
        <ResizablePanelGroup direction={isDesktop ? "horizontal" : "vertical"} className="h-full rounded-xl border border-border bg-card/30">
          <ResizablePanel defaultSize={isDesktop ? 58 : 60} minSize={30} className="flex flex-col">
            <EditorToolbar
              tabs={editorTabs}
              activeTab={activeTab}
              onTabChange={setActiveTab}
              fontSize={fontSize}
              onFontSize={setFontSize}
              onCopy={handleCopy}
              onDownload={handleDownload}
              onClear={handleClear}
              onReset={handleReset}
              copied={copied}
            />
            <div className="min-h-0 flex-1">
              <CodeEditor
                value={editorValue}
                language={editorLang}
                onChange={setEditorValue}
                fontSize={fontSize}
              />
            </div>
          </ResizablePanel>

          <ResizableHandle />

          <ResizablePanel defaultSize={isDesktop ? 42 : 40} minSize={25} className="flex flex-col">
            <Tabs value={rightTab} onValueChange={setRightTab} className="flex h-full flex-col">
              <TabsList className="mx-3 mt-3 grid auto-cols-fr grid-flow-col">
                <TabsTrigger value="console">Console</TabsTrigger>
                {language === "web" && <TabsTrigger value="preview">Preview</TabsTrigger>}
                {language !== "web" && <TabsTrigger value="input">Input</TabsTrigger>}
              </TabsList>
              <TabsContent value="console" className="mt-2 min-h-0 flex-1">
                <div className="h-full rounded-xl border border-border bg-background">
                  <ConsolePanel
                    lines={lines}
                    status={status}
                    running={running}
                    onClear={() => setLines([])}
                    meta={meta}
                  />
                </div>
              </TabsContent>
              {language === "web" && (
                <TabsContent value="preview" className="mt-2 min-h-0 flex-1">
                  <div className="h-full rounded-xl border border-border bg-background">
                    <WebPreview doc={webDoc} onOpenTab={openPreviewInTab} />
                  </div>
                </TabsContent>
              )}
              {language !== "web" && (
                <TabsContent value="input" className="mt-2 min-h-0 flex-1">
                  <div className="h-full rounded-xl border border-border bg-background">
                    <StdinPanel value={stdin} onChange={setStdin} disabled={false} />
                  </div>
                </TabsContent>
              )}
            </Tabs>
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>

      {/* Hidden sandboxed iframe for isolated JavaScript execution */}
      <iframe
        ref={jsRunnerRef}
        title="js-runner"
        sandbox="allow-scripts"
        className="pointer-events-none absolute h-0 w-0 border-0 opacity-0"
        aria-hidden="true"
      />
    </div>
  );
}